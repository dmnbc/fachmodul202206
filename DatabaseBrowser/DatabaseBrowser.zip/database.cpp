#include "database.h"
#include <QDebug>
#include <QSqlError>
#include "zugangsdaten.data"

#define debug qDebug()<<__FILE__<<":"<<__LINE__

Database::Database()
{  debug<<"ctor DB()";
}

Database::Database(QString driver)
{
    if(QSqlDatabase::isDriverAvailable(driver))
    {

        // verbinden
        db = QSqlDatabase::addDatabase("QMYSQL");


        debug<<"Treiber ist "<<db.driverName();
        db.setHostName(server);
        db.setUserName(user);
        db.setPassword(pw);
        if(db.open())
        {

           debug<<"open sucessfull";
           connected= true;
        }
        else
        {
            // Fehler ausgeben
           QSqlError err = db.lastError();
            debug<<"open failed "<<err.databaseText();
        }

    }
    else
    {
        debug<<"Treiber "<<driver<<" ist nicht verfügbar";
        debug<<"Es sind nur "<<db.drivers()<<" vorhanden";

    }

}

QSqlQuery Database::query(QString cmd)
{

    return db.exec(cmd);
}

QStringList Database::results(QString cmd)
{
    QStringList list;
    QSqlQuery q = db.exec(cmd);
    while (q.next()) {
        QString record{""};
        for(int i = 0; i < q.record().count();i++)
        {QString info = q.value(i).toString();
            debug<<"Result("<<i<<") : "<<info;
            record += info +';';}
        list.append(record);
        }
    debug<<list;
    return list;
}
